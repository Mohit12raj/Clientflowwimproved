# Edunovaa Workspace — Day 2

A front-end prototype for managing customers and service requests.
Plain HTML, CSS and vanilla JavaScript. **No backend, no API, no build step.** All data is mock data in JS objects.

## Run it

Double-click `index.html` (works in Chrome, Edge, Firefox), or serve the folder:

```bash
npx serve .            # or
python -m http.server 5500
```

**Demo login:** `admin@edunovaa.com` / `Admin@123` (or press **Fill in demo**).

---

## Day 2 requirements checklist

### 1. Login screen — `index.html`, `js/pages/login.page.js`
- [x] Email format validated (on blur and on submit)
- [x] Password is required
- [x] Clear messages: under each field + a summary alert ("Fix the 2 highlighted fields…"), wrong-credentials message, Caps Lock hint
- [x] Successful login shows a success state, then opens the Dashboard
- [x] No real authentication (`js/core/auth.js` checks a demo account)
- [x] Logout from the sidebar or the profile menu, with a confirmation dialog; login page confirms "You've signed out"

### 2. Dashboard — `dashboard.html`, `js/pages/dashboard.page.js`
- [x] All 4 summary cards are calculated from mock data (`js/core/metrics.js`)
  - Total Customers = customers who raised requests in the period (+ new sign-ups)
  - Active Services = requests in progress
  - Pending Requests = pending requests (+ high priority count)
  - Revenue = amount of completed requests
- [x] Date filter: **Today / This week / This month** — every number, the comparison chip ("▲ 40% vs last week"), trend line, table and breakdown update
- [x] Recent Service Requests table: **search**, **status filter** (with live counts), **sorting** (click any column header), "Show all" for long lists
- [x] Empty-state messages for "no results" and "no requests in this period", with a one-click fix

### 3. Customer page — `customers.html`, `js/pages/customers.page.js`
- [x] Search (name, company, email, phone, city, ID) and status filter both work, plus a service filter
- [x] **Add customer** opens a modal form: Name, Email, Phone, Status (+ optional Company, Service)
- [x] Validation: required fields, email format, duplicate email, phone digits
- [x] On submit the customer is added to the mock list (kept in `localStorage`), highlighted at the top, with a toast and a success screen
- [x] Clicking a customer opens a details drawer (contact info, totals, service requests, notes)

### 4. Reusable components — `js/components/`
| Component | File | Used for |
|---|---|---|
| Sidebar | `Sidebar.js` | Navigation on every app page |
| Header | `Header.js` | Top bar, search, alerts, profile menu |
| Summary Card | `SummaryCard.js` | The 4 dashboard cards (+ loading skeleton) |
| Button | `Button.js` | Every button/link-button, with a loading state |
| Modal | `Modal.js` | Add customer dialog, details drawer, sign-out confirm |
| Table | `DataTable.js` | Both tables: sorting, loading rows, empty state, row click |
| Input | `Input.js` | Login + add-customer fields, search boxes, error display |
| Status Badge | `StatusBadge.js` | Customer status, request status, priority |
| Extras | `FilterTabs.js`, `EmptyState.js`, `Toast.js` | Filters, empty/no-result states, notifications |

### 5. UI states
- [x] **Loading** — skeleton cards and rows while mock data "loads" (`store.mockService` adds a short delay)
- [x] **Empty** — no customers / no requests in a period
- [x] **Validation / error** — inline field errors + summary alerts
- [x] **Successful form submission** — success screen, toast, highlighted new row
- [x] **No search results** — specific message + "Clear filters"

### 6. Code quality
- [x] Mock data lives only in `js/data/` — no customer rows in HTML or component markup
- [x] Shared logic in `js/core/` (validation, dates, metrics, store); UI in `js/components/`; page wiring in `js/pages/`
- [x] One table component and one validation module reused everywhere, instead of duplicated code

### 7. Responsive design
- [x] **Desktop (1200px+)**: full sidebar, collapsible to an icon rail (remembered)
- [x] **Tablet (768–1199px)**: icon rail with tooltips; menu button expands it over the page
- [x] **Mobile (<768px)**: sidebar slides in from the left
- [x] Tables scroll inside their panel and drop low-priority columns on smaller screens, so the page never scrolls sideways

---

## Folder structure

```
edunovaa.workspace/
├── index.html                 Login
├── dashboard.html             Dashboard
├── customers.html             Customers
└── assets/
    ├── css/
    │   ├── tokens.css         Colours, type scale, spacing
    │   ├── base.css           Reset + typography
    │   ├── components.css     Styles for every reusable component
    │   ├── layout.css         Sidebar, header, page shell, breakpoints
    │   ├── pages.css          Dashboard + customer page specifics
    │   └── login.css          Login page
    └── js/
        ├── data/              Mock data only (catalog, customers, requests)
        ├── core/              utils, icons, dates, format, validators,
        │                      store (mock service), auth, metrics, app-shell
        ├── components/        Sidebar, Header, SummaryCard, Button, Modal,
        │                      DataTable, Input, StatusBadge, FilterTabs,
        │                      EmptyState, Toast
        └── pages/             login.page.js, dashboard.page.js, customers.page.js
```

## Notes
- Mock dates are stored as "days ago", so Today / This week / This month always show data whenever you open the app.
- Deep links: `customers.html?id=CUS-1001`, `?q=pune`, `?status=Pending`, `?new=1`, `dashboard.html?period=month`.
- Reset customers you added: run `EW.store.resetDemoData()` in the browser console, then reload.
