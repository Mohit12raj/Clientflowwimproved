/* ==========================================================
   Core: app shell
   Mounts the Sidebar + Header components on protected pages
   and wires shared behaviour: responsive menu, popovers,
   global search and the sign-out confirmation.

   const user = EW.shell.mount({ active: "dashboard" });
   ========================================================== */
window.EW = window.EW || {};

EW.shell = (() => {
  const COLLAPSE_KEY = "ew_sidebar_collapsed";
  const media = {
    mobile: window.matchMedia("(max-width: 767px)"),
    tablet: window.matchMedia("(min-width: 768px) and (max-width: 1199px)")
  };
  let activePage = "";

  function renderSidebar(user) {
    document.getElementById("sidebar").innerHTML = EW.ui.Sidebar({ active: activePage, user });
  }

  /* Layout modes
     desktop (1200px+)  : full sidebar, can be collapsed to an icon rail (remembered)
     tablet (768-1199)  : icon rail, the menu button expands it over the page
     mobile (<768)      : hidden, the menu button slides it in               */
  function syncLayout() {
    const body = document.body;
    const open = body.classList.contains("sidebar-open");
    const collapsed = EW.utils.storage.get(COLLAPSE_KEY, false);
    const rail = media.tablet.matches ? !open : (!media.mobile.matches && collapsed);
    body.classList.toggle("is-rail", rail);
    const toggle = document.querySelector("[data-menu-toggle]");
    if (toggle) toggle.setAttribute("aria-expanded", String(media.mobile.matches || media.tablet.matches ? open : !collapsed));
  }

  function setMenuOpen(open) {
    document.body.classList.toggle("sidebar-open", open);
    syncLayout();
  }

  function bindMenu() {
    document.querySelector("[data-menu-toggle]").addEventListener("click", () => {
      if (media.mobile.matches || media.tablet.matches) {
        setMenuOpen(!document.body.classList.contains("sidebar-open"));
      } else {
        EW.utils.storage.set(COLLAPSE_KEY, !EW.utils.storage.get(COLLAPSE_KEY, false));
        syncLayout();
      }
    });
    document.getElementById("scrim").addEventListener("click", () => setMenuOpen(false));
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && document.body.classList.contains("sidebar-open")) setMenuOpen(false);
    });
    // Changing screen size should never leave the drawer stuck open
    [media.mobile, media.tablet].forEach(m => m.addEventListener("change", () => setMenuOpen(false)));
    syncLayout();
  }

  function bindPopovers() {
    const closeAll = () => document.querySelectorAll("[data-popover]").forEach(btn => {
      btn.setAttribute("aria-expanded", "false");
      document.getElementById("popover-" + btn.dataset.popover)?.classList.remove("is-open");
    });
    document.addEventListener("click", (e) => {
      const trigger = e.target.closest("[data-popover]");
      if (!trigger) { if (!e.target.closest(".popover") || e.target.closest(".popover-item")) closeAll(); return; }
      const pop = document.getElementById("popover-" + trigger.dataset.popover);
      const willOpen = !pop.classList.contains("is-open");
      closeAll();
      pop.classList.toggle("is-open", willOpen);
      trigger.setAttribute("aria-expanded", String(willOpen));
    });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeAll(); });
  }

  function bindLogout() {
    document.addEventListener("click", async (e) => {
      if (!e.target.closest("[data-logout]")) return;
      const confirmed = await EW.ui.Modal.confirm({
        title: "Sign out of the workspace?",
        message: "You'll need your email and password to sign back in. Customers you added stay saved on this browser.",
        confirmLabel: "Sign out",
        tone: "danger"
      });
      if (confirmed) EW.auth.logout();
    });
  }

  function bindGlobalSearch() {
    const form = document.querySelector("[data-global-search]");
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const query = form.querySelector("input").value.trim();
      if (typeof EW.shell.onSearch === "function") { EW.shell.onSearch(query); return; }
      window.location.href = "customers.html" + (query ? "?q=" + encodeURIComponent(query) : "");
    });
  }

  return {
    onSearch: null,

    mount({ active }) {
      EW.auth.requireAuth();
      const user = EW.auth.currentUser() || { name: "Guest", role: "", email: "" };
      activePage = active;

      const alerts = EW.store.getRequests()
        .filter(r => r.status === "Pending" && r.priority === "High")
        .sort((a, b) => b.requestedOn.localeCompare(a.requestedOn));

      renderSidebar(user);
      document.getElementById("topbar").innerHTML = EW.ui.Header({ user, alerts });

      bindMenu();
      bindPopovers();
      bindLogout();
      bindGlobalSearch();
      return user;
    },

    /** Re-render sidebar counts after data changes */
    refresh() { renderSidebar(EW.auth.currentUser()); },

    setSearchValue(value) {
      const input = document.getElementById("globalSearchInput");
      if (input) input.value = value;
    }
  };
})();
