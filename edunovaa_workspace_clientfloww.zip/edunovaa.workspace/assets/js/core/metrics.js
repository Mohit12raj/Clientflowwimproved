/* ==========================================================
   Core: dashboard calculations (pure functions, no DOM)
   ========================================================== */
window.EW = window.EW || {};

EW.metrics = (() => {
  const { inRange } = EW.dates;

  function summarize(requests, customers, range) {
    const inPeriod   = requests.filter(r => inRange(r.requestedOn, range));
    const inProgress = inPeriod.filter(r => r.status === "In progress");
    const pending    = inPeriod.filter(r => r.status === "Pending");
    const completed  = inPeriod.filter(r => r.status === "Completed");

    return {
      requests: inPeriod.length,
      customers: new Set(inPeriod.map(r => r.customerId)).size,
      newCustomers: customers.filter(c => inRange(c.joinedOn, range)).length,
      activeServices: inProgress.length,
      serviceLines: new Set(inProgress.map(r => r.service)).size,
      pending: pending.length,
      pendingHigh: pending.filter(r => r.priority === "High").length,
      revenue: completed.reduce((sum, r) => sum + (Number(r.amount) || 0), 0),
      completed: completed.length
    };
  }

  /** Daily values of one metric, for the small trend line */
  function dailySeries(requests, customers, range, key) {
    return EW.dates.eachDay(range).map(day => summarize(requests, customers, { start: day, end: day, days: 1 })[key]);
  }

  /** Percentage change, or null when there's nothing to compare against */
  function change(current, previous) {
    if (!previous) return current ? null : 0;
    return Math.round(((current - previous) / previous) * 100);
  }

  function countBy(list, key, keys) {
    return keys.map(k => ({ label: k, count: list.filter(item => item[key] === k).length }));
  }

  return { summarize, dailySeries, change, countBy };
})();
