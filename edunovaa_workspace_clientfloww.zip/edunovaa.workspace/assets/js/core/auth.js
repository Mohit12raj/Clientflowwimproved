/* ==========================================================
   Core: front-end only authentication (no real auth)
   The session is a small object in browser storage.
   ========================================================== */
window.EW = window.EW || {};

EW.auth = (() => {
  const KEY = "ew_session";
  const USER = EW.data.demoUser;

  function read() {
    try { return JSON.parse(sessionStorage.getItem(KEY) || localStorage.getItem(KEY) || "null"); }
    catch (e) { return null; }
  }

  return {
    demoUser: { email: USER.email, password: USER.password },

    /** Returns { ok: true } or { ok: false, message } */
    login(email, password, remember) {
      const cleanEmail = String(email).trim().toLowerCase();
      if (cleanEmail !== USER.email || password !== USER.password) {
        return { ok: false, message: "That email and password don't match our records. Check both and try again." };
      }
      const session = { name: USER.name, email: USER.email, role: USER.role, signedInAt: Date.now() };
      try { (remember ? localStorage : sessionStorage).setItem(KEY, JSON.stringify(session)); } catch (e) {}
      return { ok: true };
    },

    currentUser() { return read(); },

    logout() {
      try { sessionStorage.removeItem(KEY); localStorage.removeItem(KEY); sessionStorage.setItem("ew_signed_out", "1"); } catch (e) {}
      window.location.replace("index.html");
    },

    requireAuth() { if (!read()) window.location.replace("index.html"); },
    redirectIfSignedIn() { if (read()) window.location.replace("dashboard.html"); }
  };
})();
