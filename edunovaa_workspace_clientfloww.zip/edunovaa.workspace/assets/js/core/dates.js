/* ==========================================================
   Core: date helpers + dashboard periods
   Periods are rolling windows ending today, so each filter
   always covers a different span:
     Today      -> today only
     This week  -> last 7 days including today
     This month -> last 30 days including today
   ========================================================== */
window.EW = window.EW || {};

EW.dates = (() => {
  const pad = (n) => String(n).padStart(2, "0");
  const toISO = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const startOfToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };

  const PERIODS = {
    today: { label: "Today",      days: 1,  phrase: "today",      compareLabel: "yesterday" },
    week:  { label: "This week",  days: 7,  phrase: "this week",  compareLabel: "last week" },
    month: { label: "This month", days: 30, phrase: "this month", compareLabel: "last month" }
  };

  function daysAgo(n) {
    const d = startOfToday();
    d.setDate(d.getDate() - n);
    return toISO(d);
  }

  return {
    PERIODS,
    toISO,
    daysAgo,
    todayISO: () => toISO(startOfToday()),

    diffDays(laterISO, earlierISO) {
      const a = new Date(laterISO + "T00:00:00"), b = new Date(earlierISO + "T00:00:00");
      return Math.round((a - b) / 86400000);
    },

    /** shift = 0 for the current period, 1 for the one before it */
    rangeFor(periodKey, shift = 0) {
      const { days } = PERIODS[periodKey];
      const endOffset = shift * days;
      return { start: daysAgo(endOffset + days - 1), end: daysAgo(endOffset), days };
    },

    inRange(iso, range) { return Boolean(iso) && iso >= range.start && iso <= range.end; },

    /** List of ISO days inside a range, oldest first */
    eachDay(range) {
      const out = [];
      for (let i = range.days - 1; i >= 0; i--) out.push(daysAgo(EW.dates.diffDays(EW.dates.todayISO(), range.end) + i));
      return out;
    },

    describeRange(range) {
      if (range.start === range.end) return EW.format.date(range.end);
      return `${EW.format.dayMonth(range.start)} to ${EW.format.date(range.end)}`;
    }
  };
})();
