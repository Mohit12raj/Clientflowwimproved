/* ==========================================================
   Core: reusable form validation
   A schema maps field names to a list of rules. Each rule
   returns an error message string, or "" when valid.
   ========================================================== */
window.EW = window.EW || {};

EW.validate = (() => {
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const PHONE_DIGITS_RE = /^\+?[0-9\s-]+$/;

  const rules = {
    required: (message) => (v) => (String(v ?? "").trim() ? "" : message),
    email: (message = "Enter a valid email, like name@company.com.") =>
      (v) => (!v || EMAIL_RE.test(String(v).trim()) ? "" : message),
    minLength: (n, message) => (v) => (!v || String(v).trim().length >= n ? "" : message),
    phone: (message = "Enter a valid phone number with 10 to 13 digits.") => (v) => {
      if (!v) return "";
      const digits = String(v).replace(/\D/g, "");
      return PHONE_DIGITS_RE.test(v) && digits.length >= 10 && digits.length <= 13 ? "" : message;
    },
    unique: (isTaken, message) => (v) => (v && isTaken(String(v).trim()) ? message : "")
  };

  /** Validate one value against its rule list; returns the first error */
  function field(value, ruleList = []) {
    for (const rule of ruleList) {
      const error = rule(value);
      if (error) return error;
    }
    return "";
  }

  /** Validate all values; returns { valid, errors: {name: message} } */
  function form(values, schema) {
    const errors = {};
    Object.entries(schema).forEach(([name, ruleList]) => {
      const error = field(values[name], ruleList);
      if (error) errors[name] = error;
    });
    return { valid: Object.keys(errors).length === 0, errors };
  }

  return { rules, field, form, EMAIL_RE };
})();
