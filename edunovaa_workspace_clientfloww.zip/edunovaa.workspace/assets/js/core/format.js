/* ==========================================================
   Core: number, currency and date formatting (Indian style)
   ========================================================== */
window.EW = window.EW || {};

EW.format = {
  inr(amount) {
    return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(amount || 0);
  },
  /** ₹1,85,000 -> ₹1.85 L ; ₹2,40,00,000 -> ₹2.4 Cr */
  inrCompact(amount) {
    const n = amount || 0;
    if (n >= 1e7) return "₹" + (n / 1e7).toFixed(2).replace(/\.?0+$/, "") + " Cr";
    if (n >= 1e5) return "₹" + (n / 1e5).toFixed(2).replace(/\.?0+$/, "") + " L";
    return EW.format.inr(n);
  },
  number(n) { return new Intl.NumberFormat("en-IN").format(n || 0); },
  date(iso) {
    if (!iso) return "—";
    return new Date(iso + "T00:00:00").toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
  },
  dayMonth(iso) {
    return new Date(iso + "T00:00:00").toLocaleDateString("en-IN", { day: "numeric", month: "short" });
  },
  /** "Today", "Yesterday", "3 days ago" or a date */
  relativeDate(iso) {
    const days = EW.dates.diffDays(EW.dates.todayISO(), iso);
    if (days === 0) return "Today";
    if (days === 1) return "Yesterday";
    if (days > 1 && days < 7) return `${days} days ago`;
    return EW.format.date(iso);
  },
  plural(n, one, many = one + "s") { return `${EW.format.number(n)} ${n === 1 ? one : many}`; }
};
