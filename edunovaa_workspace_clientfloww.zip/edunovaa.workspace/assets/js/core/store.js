/* ==========================================================
   Core: mock data store (no backend, no API)
   - Reads the plain objects in /js/data
   - Converts "days ago" fields into real dates
   - Customers added from the UI are saved in localStorage
   - mockService wraps reads in a short delay so the UI can
     show real loading states, like it would with a server
   ========================================================== */
window.EW = window.EW || {};

EW.store = (() => {
  const ADDED_KEY = "ew_day2_customers_added";
  const { daysAgo } = EW.dates;

  const seedCustomers = EW.data.customers.map(({ joinedDaysAgo, ...c }) => ({ ...c, joinedOn: daysAgo(joinedDaysAgo) }));
  const seedRequests  = EW.data.requests.map(({ requestedDaysAgo, ...r }) => ({ ...r, requestedOn: daysAgo(requestedDaysAgo) }));

  const readAdded = () => EW.utils.storage.get(ADDED_KEY, []);

  const store = {
    getCustomers() { return [...readAdded(), ...seedCustomers]; },
    getCustomer(id) { return store.getCustomers().find(c => c.id === id) || null; },
    emailExists(email) { return store.getCustomers().some(c => c.email.toLowerCase() === email.toLowerCase()); },

    addCustomer(input) {
      const all = store.getCustomers();
      const maxId = all.reduce((m, c) => Math.max(m, parseInt(c.id.split("-")[1], 10) || 0), 1000);
      const customer = {
        id: "CUS-" + (maxId + 1),
        name: input.name,
        email: input.email,
        phone: input.phone,
        status: input.status,
        company: input.company || "",
        service: input.service || "",
        city: input.city || "",
        notes: input.notes || "",
        totalBilled: 0,
        joinedOn: EW.dates.todayISO(),
        isNew: true
      };
      EW.utils.storage.set(ADDED_KEY, [customer, ...readAdded()]);
      return customer;
    },

    getRequests() { return seedRequests.slice(); },
    getRequestsFor(customerId) { return seedRequests.filter(r => r.customerId === customerId); },

    /** Run EW.store.resetDemoData() in the console to remove added customers */
    resetDemoData() { EW.utils.storage.remove(ADDED_KEY); }
  };

  /* Simulated network latency, so loading states are visible */
  const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));
  store.mockService = {
    async fetchCustomers()          { await wait(650); return store.getCustomers(); },
    async fetchRequests()           { await wait(450); return store.getRequests(); },
    async saveCustomer(input)       { await wait(700); return store.addCustomer(input); }
  };

  return store;
})();
