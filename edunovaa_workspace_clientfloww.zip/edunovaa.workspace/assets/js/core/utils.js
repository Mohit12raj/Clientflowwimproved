/* ==========================================================
   Core: small DOM + string helpers shared by every file
   ========================================================== */
window.EW = window.EW || {};

EW.utils = {
  $(selector, root = document) { return root.querySelector(selector); },
  $$(selector, root = document) { return Array.from(root.querySelectorAll(selector)); },

  escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, ch => (
      { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]
    ));
  },

  /** Build an attribute string from an object: {id:"a", disabled:true} -> ' id="a" disabled' */
  attrs(map = {}) {
    return Object.entries(map)
      .filter(([, v]) => v !== false && v !== null && v !== undefined)
      .map(([k, v]) => (v === true ? ` ${k}` : ` ${k}="${EW.utils.escapeHTML(v)}"`))
      .join("");
  },

  /** Join class names, skipping falsy values */
  cx(...names) { return names.filter(Boolean).join(" "); },

  debounce(fn, wait = 200) {
    let timer;
    return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), wait); };
  },

  initials(name = "") {
    return name.trim().split(/\s+/).slice(0, 2).map(p => p[0] || "").join("").toUpperCase() || "?";
  },

  /** Stable avatar colour per name */
  avatarColor(name = "") {
    const palette = ["#0E6B68", "#2F6FAF", "#8A4FB0", "#B4632A", "#3F7D3A", "#A33C5B", "#4B5D8A", "#7A6420"];
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
    return palette[hash % palette.length];
  },

  getQueryParam(key) { return new URLSearchParams(window.location.search).get(key); },

  setQueryParam(key, value) {
    const url = new URL(window.location.href);
    value ? url.searchParams.set(key, value) : url.searchParams.delete(key);
    history.replaceState(null, "", url);
  },

  /** Case-insensitive "every word appears somewhere" search */
  matchesQuery(fields, query) {
    if (!query) return true;
    const haystack = fields.join(" ").toLowerCase();
    return query.toLowerCase().split(/\s+/).filter(Boolean).every(term => haystack.includes(term));
  },

  /** Generic comparator for table sorting */
  compare(a, b) {
    if (typeof a === "number" && typeof b === "number") return a - b;
    return String(a ?? "").localeCompare(String(b ?? ""), "en-IN", { numeric: true, sensitivity: "base" });
  },

  storage: {
    get(key, fallback = null) {
      try { const raw = localStorage.getItem(key); return raw === null ? fallback : JSON.parse(raw); }
      catch (e) { return fallback; }
    },
    set(key, value) {
      try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* storage blocked */ }
    },
    remove(key) { try { localStorage.removeItem(key); } catch (e) {} }
  }
};
