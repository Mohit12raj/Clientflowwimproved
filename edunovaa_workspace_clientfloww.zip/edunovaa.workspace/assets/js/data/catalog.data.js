/* ==========================================================
   Mock data: lookup lists (services, statuses, priorities)
   Pure data only. No UI code lives in this folder.
   ========================================================== */
window.EW = window.EW || {};
EW.data = EW.data || {};

EW.data.services = [
  "Website Development",
  "Mobile App Development",
  "SEO & Digital Marketing",
  "Cloud Hosting",
  "IT Support (AMC)",
  "LMS Setup"
];

EW.data.customerStatuses = ["Active", "Pending", "Inactive"];
EW.data.requestStatuses  = ["Pending", "In progress", "Completed", "Cancelled"];
EW.data.priorities       = ["High", "Medium", "Low"];

/* Demo account used by the front-end login (no real auth) */
EW.data.demoUser = {
  email: "admin@edunovaa.com",
  password: "Admin@123",
  name: "Mohit Raj",
  role: "Operations lead"
};
