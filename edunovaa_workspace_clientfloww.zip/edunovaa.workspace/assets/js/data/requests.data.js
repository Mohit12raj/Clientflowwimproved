/* ==========================================================
   Mock data: service requests
   requestedDaysAgo: 0 = today, 1 = yesterday, and so on.
   Revenue on the dashboard = amount of Completed requests.
   ========================================================== */
window.EW = window.EW || {};
EW.data = EW.data || {};

EW.data.requests = [
  // Today
  { id: "SR-3046", customerId: "CUS-1017", service: "SEO & Digital Marketing", title: "Festive campaign proposal",         requestedDaysAgo: 0,  priority: "High",   status: "Pending",     amount: 32000 },
  { id: "SR-3045", customerId: "CUS-1009", service: "Mobile App Development",  title: "Fix order tracking crash",          requestedDaysAgo: 0,  priority: "High",   status: "In progress", amount: 12000 },
  { id: "SR-3044", customerId: "CUS-1005", service: "IT Support (AMC)",        title: "Printer setup at Branch 2",         requestedDaysAgo: 0,  priority: "Low",    status: "Completed",   amount: 3500 },
  { id: "SR-3043", customerId: "CUS-1016", service: "LMS Setup",               title: "Import student list for Class 9",   requestedDaysAgo: 0,  priority: "Medium", status: "Pending",     amount: 6000 },
  // Yesterday
  { id: "SR-3042", customerId: "CUS-1013", service: "IT Support (AMC)",        title: "Network audit for new office",      requestedDaysAgo: 1,  priority: "High",   status: "Pending",     amount: 45000 },
  { id: "SR-3041", customerId: "CUS-1003", service: "Cloud Hosting",           title: "Nightly database backup",           requestedDaysAgo: 1,  priority: "Medium", status: "Completed",   amount: 8000 },
  { id: "SR-3040", customerId: "CUS-1012", service: "Website Development",     title: "Membership page",                   requestedDaysAgo: 1,  priority: "Medium", status: "In progress", amount: 18000 },
  // Rest of the last 7 days
  { id: "SR-3039", customerId: "CUS-1007", service: "Mobile App Development",  title: "Quote: property listing app",       requestedDaysAgo: 2,  priority: "Medium", status: "Pending",     amount: 280000 },
  { id: "SR-3038", customerId: "CUS-1001", service: "LMS Setup",               title: "Batch-wise attendance",             requestedDaysAgo: 3,  priority: "Medium", status: "In progress", amount: 22000 },
  { id: "SR-3037", customerId: "CUS-1015", service: "Website Development",     title: "Add WhatsApp enquiry button",       requestedDaysAgo: 3,  priority: "Low",    status: "Completed",   amount: 4500 },
  { id: "SR-3036", customerId: "CUS-1004", service: "SEO & Digital Marketing", title: "Instagram campaign for Diwali",     requestedDaysAgo: 4,  priority: "Medium", status: "Pending",     amount: 36000 },
  { id: "SR-3035", customerId: "CUS-1006", service: "LMS Setup",               title: "Parent login module",               requestedDaysAgo: 5,  priority: "Medium", status: "Completed",   amount: 40000 },
  { id: "SR-3034", customerId: "CUS-1018", service: "Cloud Hosting",           title: "SSL certificate renewal",           requestedDaysAgo: 6,  priority: "High",   status: "Completed",   amount: 5000 },
  { id: "SR-3033", customerId: "CUS-1008", service: "Website Development",     title: "Domain renewal",                    requestedDaysAgo: 6,  priority: "Low",    status: "Cancelled",   amount: 0 },
  // 7 to 29 days ago
  { id: "SR-3055", customerId: "CUS-1002", service: "Website Development",     title: "Clinic gallery page",               requestedDaysAgo: 7,  priority: "Low",    status: "Completed",   amount: 9000 },
  { id: "SR-3054", customerId: "CUS-1014", service: "LMS Setup",               title: "Bulk SMS for exam dates",           requestedDaysAgo: 7,  priority: "Medium", status: "Pending",     amount: 7000 },
  { id: "SR-3053", customerId: "CUS-1001", service: "LMS Setup",               title: "Teacher login for new centre",      requestedDaysAgo: 8,  priority: "High",   status: "Completed",   amount: 12000 },
  { id: "SR-3052", customerId: "CUS-1005", service: "IT Support (AMC)",        title: "CCTV network check",                requestedDaysAgo: 9,  priority: "Medium", status: "In progress", amount: 6500 },
  { id: "SR-3051", customerId: "CUS-1009", service: "Mobile App Development",  title: "Push notification offers",          requestedDaysAgo: 10, priority: "Medium", status: "Pending",     amount: 18000 },
  { id: "SR-3050", customerId: "CUS-1006", service: "LMS Setup",               title: "Library module",                    requestedDaysAgo: 10, priority: "Low",    status: "Completed",   amount: 14000 },
  { id: "SR-3049", customerId: "CUS-1003", service: "Cloud Hosting",           title: "Load balancer setup",               requestedDaysAgo: 11, priority: "High",   status: "In progress", amount: 24000 },
  { id: "SR-3048", customerId: "CUS-1018", service: "Cloud Hosting",           title: "Email hosting for clinic",          requestedDaysAgo: 12, priority: "Low",    status: "Completed",   amount: 6000 },
  { id: "SR-3047", customerId: "CUS-1012", service: "Website Development",     title: "Trainer profiles page",             requestedDaysAgo: 13, priority: "Medium", status: "Pending",     amount: 11000 },
  { id: "SR-3032", customerId: "CUS-1002", service: "Website Development",     title: "Online appointment booking",        requestedDaysAgo: 8,  priority: "Low",    status: "Pending",     amount: 28000 },
  { id: "SR-3031", customerId: "CUS-1005", service: "IT Support (AMC)",        title: "Replace router at Branch 3",        requestedDaysAgo: 9,  priority: "High",   status: "Completed",   amount: 8500 },
  { id: "SR-3030", customerId: "CUS-1010", service: "SEO & Digital Marketing", title: "Monthly SEO report",                requestedDaysAgo: 11, priority: "Low",    status: "Completed",   amount: 9000 },
  { id: "SR-3029", customerId: "CUS-1014", service: "LMS Setup",               title: "Online test module",                requestedDaysAgo: 12, priority: "Medium", status: "In progress", amount: 26000 },
  { id: "SR-3028", customerId: "CUS-1016", service: "LMS Setup",               title: "Marathi language pack",             requestedDaysAgo: 14, priority: "Medium", status: "Completed",   amount: 15000 },
  { id: "SR-3027", customerId: "CUS-1009", service: "Mobile App Development",  title: "Payment gateway timeout",           requestedDaysAgo: 16, priority: "High",   status: "Completed",   amount: 15000 },
  { id: "SR-3026", customerId: "CUS-1015", service: "Website Development",     title: "Product catalogue site",            requestedDaysAgo: 20, priority: "Medium", status: "Completed",   amount: 38000 },
  { id: "SR-3025", customerId: "CUS-1003", service: "Cloud Hosting",           title: "Increase server storage",           requestedDaysAgo: 22, priority: "Low",    status: "Completed",   amount: 12000 },
  { id: "SR-3024", customerId: "CUS-1012", service: "Website Development",     title: "Class timetable page",              requestedDaysAgo: 25, priority: "Low",    status: "Cancelled",   amount: 0 },
  { id: "SR-3023", customerId: "CUS-1018", service: "Cloud Hosting",           title: "Migrate clinic site to cloud",      requestedDaysAgo: 28, priority: "Medium", status: "Completed",   amount: 22000 },
  // 30 to 60 days ago (used for "vs previous period" comparison)
  { id: "SR-3022", customerId: "CUS-1001", service: "LMS Setup",               title: "Fee reminder SMS",                  requestedDaysAgo: 31, priority: "Medium", status: "Completed",   amount: 14000 },
  { id: "SR-3021", customerId: "CUS-1006", service: "LMS Setup",               title: "Report card templates",             requestedDaysAgo: 34, priority: "Low",    status: "Completed",   amount: 11000 },
  { id: "SR-3020", customerId: "CUS-1009", service: "Mobile App Development",  title: "Coupon feature",                    requestedDaysAgo: 37, priority: "Medium", status: "Completed",   amount: 30000 },
  { id: "SR-3019", customerId: "CUS-1005", service: "IT Support (AMC)",        title: "Quarterly maintenance visit",       requestedDaysAgo: 40, priority: "Low",    status: "Completed",   amount: 12000 },
  { id: "SR-3018", customerId: "CUS-1014", service: "LMS Setup",               title: "Initial LMS setup",                 requestedDaysAgo: 46, priority: "High",   status: "Completed",   amount: 60000 },
  { id: "SR-3017", customerId: "CUS-1010", service: "SEO & Digital Marketing", title: "Google Business profile",           requestedDaysAgo: 50, priority: "Low",    status: "Completed",   amount: 7000 },
  { id: "SR-3016", customerId: "CUS-1011", service: "Cloud Hosting",           title: "Data export before exit",           requestedDaysAgo: 55, priority: "Medium", status: "Cancelled",   amount: 0 },
  { id: "SR-3015", customerId: "CUS-1012", service: "Website Development",     title: "Studio website launch",             requestedDaysAgo: 58, priority: "High",   status: "Completed",   amount: 38000 }
];
