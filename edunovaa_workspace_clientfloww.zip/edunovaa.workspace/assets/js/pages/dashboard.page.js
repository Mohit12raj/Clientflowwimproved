/* ==========================================================
   Page: Dashboard
   - Period filter (Today / This week / This month) drives the
     4 summary cards, the requests table and both breakdowns
   - Recent service requests: search, status filter, sorting
   - Loading skeletons and empty states
   ========================================================== */
(function () {
  const user = EW.shell.mount({ active: "dashboard" });
  const { SummaryCard, DataTable, FilterTabs, SearchInput, StatusBadge, EmptyState, Button } = EW.ui;
  const { escapeHTML, initials, avatarColor, matchesQuery, debounce } = EW.utils;
  const { PERIODS } = EW.dates;
  const fmt = EW.format;

  const state = {
    period: EW.utils.getQueryParam("period") in PERIODS ? EW.utils.getQueryParam("period") : "week",
    query: "",
    status: "All",
    requests: [],
    customers: EW.store.getCustomers()
  };
  const customerById = Object.fromEntries(state.customers.map(c => [c.id, c]));

  /* ---------- Page header ---------- */
  const now = new Date();
  const hour = now.getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  document.getElementById("greeting").textContent = `${greeting}, ${user.name.split(" ")[0]}`;
  document.getElementById("headerActions").innerHTML =
    Button({ label: "View customers", variant: "secondary", href: "customers.html" }) +
    Button({ label: "Add customer", icon: "plus", href: "customers.html?new=1" });

  /* ---------- Period filter ---------- */
  const periodEl = document.getElementById("periodFilter");
  function renderPeriodFilter() {
    periodEl.innerHTML = FilterTabs({
      label: "Dashboard period", variant: "period", value: state.period,
      options: Object.entries(PERIODS).map(([value, p]) => ({ value, label: p.label }))
    });
    document.getElementById("periodRange").textContent = EW.dates.describeRange(EW.dates.rangeFor(state.period));
  }
  FilterTabs.bind(periodEl, (value) => {
    if (value === state.period) return;
    state.period = value;
    EW.utils.setQueryParam("period", value === "week" ? "" : value);
    renderPeriodFilter();
    refresh({ simulateLoad: true });
  });

  /* ---------- Summary cards ---------- */
  const cardsEl = document.getElementById("summaryCards");

  function renderSummary() {
    const range = EW.dates.rangeFor(state.period);
    const previous = EW.dates.rangeFor(state.period, 1);
    const { summarize, dailySeries, change } = EW.metrics;
    const current = summarize(state.requests, state.customers, range);
    const before = summarize(state.requests, state.customers, previous);
    const compareLabel = PERIODS[state.period].compareLabel;
    const series = (key) => state.period === "today" ? [] : dailySeries(state.requests, state.customers, range, key);

    const cards = [
      {
        label: "Total Customers", icon: "users", tone: "teal",
        value: fmt.number(current.customers),
        note: `served ${PERIODS[state.period].phrase}${current.newCustomers ? `, <strong>${current.newCustomers} new</strong> signed up` : ""}`,
        change: change(current.customers, before.customers), series: series("customers")
      },
      {
        label: "Active Services", icon: "activity", tone: "blue",
        value: fmt.number(current.activeServices),
        note: current.activeServices ? `in progress across ${fmt.plural(current.serviceLines, "service line")}` : "nothing in progress right now",
        change: change(current.activeServices, before.activeServices), series: series("activeServices")
      },
      {
        label: "Pending Requests", icon: "clock", tone: "marigold", invertChange: true,
        value: fmt.number(current.pending),
        note: current.pendingHigh ? `<strong>${current.pendingHigh} high priority</strong> waiting for a reply` : "no high-priority requests waiting",
        change: change(current.pending, before.pending), series: series("pending")
      },
      {
        label: "Revenue", icon: "rupee", tone: "plum",
        value: fmt.inrCompact(current.revenue),
        note: current.completed ? `from ${fmt.plural(current.completed, "completed request")}` : "no requests completed yet",
        change: change(current.revenue, before.revenue), series: series("revenue")
      }
    ];
    cardsEl.innerHTML = cards.map(card => SummaryCard({ ...card, compareLabel })).join("");
  }

  /* ---------- Recent service requests ---------- */
  const toolbarEl = document.getElementById("requestsToolbar");
  const countEl = document.getElementById("requestsCount");
  toolbarEl.innerHTML = `
    ${SearchInput({ id: "requestSearch", label: "Search service requests", placeholder: "Search request, customer or ID" })}
    <div id="requestStatusFilter"></div>`;
  const statusFilterEl = document.getElementById("requestStatusFilter");

  const requestsTable = new DataTable(document.getElementById("requestsTable"), {
    caption: "Recent service requests",
    sort: { key: "requestedOn", dir: "desc" },
    skeletonRows: 5,
    pageSize: 8,
    rowLabel: (r) => `Open ${r.customerName}, request ${r.id}`,
    onRowClick: (r) => { window.location.href = "customers.html?id=" + encodeURIComponent(r.customerId); },
    columns: [
      { key: "title", label: "Request", sortable: true, render: (r) => `
          <div class="cell-stack"><strong>${escapeHTML(r.title)}</strong>
          <span class="cell-sub"><span class="id-tag">${r.id}</span>${escapeHTML(r.service)}</span></div>` },
      { key: "customerName", label: "Customer", sortable: true, render: (r) => `
          <div class="cell-person">
            <span class="avatar avatar-sm" style="background:${avatarColor(r.customerName)}">${initials(r.customerName)}</span>
            <div class="cell-stack"><strong>${escapeHTML(r.customerName)}</strong><span class="cell-sub">${escapeHTML(r.company)}</span></div>
          </div>` },
      { key: "requestedOn", label: "Raised", sortable: true, hideBelow: "md", render: (r) => `<span class="cell-muted">${fmt.relativeDate(r.requestedOn)}</span>` },
      { key: "priority", label: "Priority", sortable: true, hideBelow: "sm", sortValue: (r) => ["High", "Medium", "Low"].indexOf(r.priority), render: (r) => StatusBadge(r.priority, "priority") },
      { key: "status", label: "Status", sortable: true, render: (r) => StatusBadge(r.status, "request") },
      { key: "amount", label: "Amount", sortable: true, align: "right", hideBelow: "sm", render: (r) => `<span class="num strong">${r.amount ? fmt.inr(r.amount) : "—"}</span>` }
    ],
    emptyState: () => {
      const filtered = state.query || state.status !== "All";
      if (filtered) {
        return EmptyState({
          icon: "filterOff", title: "No requests match these filters",
          message: state.query ? `Nothing raised ${PERIODS[state.period].phrase} matches “${state.query}”${state.status !== "All" ? ` with status ${state.status}` : ""}. Check the spelling or clear the filters.` : `There are no ${state.status.toLowerCase()} requests ${PERIODS[state.period].phrase}.`,
          actions: [{ label: "Clear filters", action: "clear-filters", icon: "x" }]
        });
      }
      return EmptyState({
        icon: "inbox", title: `No service requests ${state.period === "today" ? "today" : "in this period"}`,
        message: "New requests from customers will show up here.",
        actions: state.period !== "month" ? [{ label: "Show this month", action: "show-month" }] : []
      });
    },
    onAction: (action) => {
      if (action === "clear-filters") {
        state.query = ""; state.status = "All";
        document.getElementById("requestSearch").value = "";
        renderRequests();
      }
      if (action === "show-month") periodEl.querySelector('[data-value="month"]').click();
    }
  });

  function requestsInPeriod() {
    const range = EW.dates.rangeFor(state.period);
    return state.requests
      .filter(r => EW.dates.inRange(r.requestedOn, range))
      .map(r => {
        const c = customerById[r.customerId] || { name: "Unknown customer", company: "" };
        return { ...r, customerName: c.name, company: c.company };
      });
  }

  function renderRequests() {
    const periodRows = requestsInPeriod();
    const searched = periodRows.filter(r => matchesQuery([r.title, r.id, r.service, r.customerName, r.company], state.query));
    const visible = state.status === "All" ? searched : searched.filter(r => r.status === state.status);

    statusFilterEl.innerHTML = FilterTabs({
      label: "Filter requests by status", value: state.status,
      options: ["All", ...EW.data.requestStatuses].map(s => ({
        value: s, label: s, count: s === "All" ? searched.length : searched.filter(r => r.status === s).length
      }))
    });
    countEl.textContent = `${visible.length} of ${fmt.plural(periodRows.length, "request")} ${PERIODS[state.period].phrase}`;
    requestsTable.setRows(visible);
  }

  document.getElementById("requestSearch").addEventListener("input", debounce((e) => {
    state.query = e.target.value.trim();
    renderRequests();
  }, 180));
  FilterTabs.bind(statusFilterEl, (value) => { state.status = value; renderRequests(); });

  /* ---------- Breakdowns ---------- */
  function bar(label, count, total, tone) {
    const pct = total ? Math.round((count / total) * 100) : 0;
    return `
      <div class="bar-row">
        <div class="bar-label"><span>${escapeHTML(label)}</span><span class="num">${count}</span></div>
        <div class="bar-track" role="img" aria-label="${escapeHTML(label)}: ${count} of ${total}"><span class="bar-fill tone-${tone}" style="width:${pct}%"></span></div>
      </div>`;
  }

  function renderBreakdowns() {
    const rows = requestsInPeriod();
    const tones = { Pending: "marigold", "In progress": "blue", Completed: "teal", Cancelled: "grey" };
    const statusEl = document.getElementById("statusBreakdown");
    const serviceEl = document.getElementById("serviceBreakdown");

    if (!rows.length) {
      const empty = EmptyState({ icon: "chart", title: "No data for this period", compact: true });
      statusEl.innerHTML = empty; serviceEl.innerHTML = empty;
      return;
    }
    statusEl.innerHTML = EW.metrics.countBy(rows, "status", EW.data.requestStatuses)
      .map(s => bar(s.label, s.count, rows.length, tones[s.label])).join("");
    serviceEl.innerHTML = EW.metrics.countBy(rows, "service", EW.data.services)
      .filter(s => s.count).sort((a, b) => b.count - a.count)
      .map(s => bar(s.label, s.count, rows.length, "ink")).join("");
  }

  /* ---------- Loading + refresh ---------- */
  function showLoading() {
    cardsEl.innerHTML = Array.from({ length: 4 }, SummaryCard.skeleton).join("");
    cardsEl.setAttribute("aria-busy", "true");
    requestsTable.setLoading(true);
    countEl.textContent = "Loading requests…";
  }

  function renderAll() {
    cardsEl.removeAttribute("aria-busy");
    renderSummary();
    renderRequests();
    renderBreakdowns();
  }

  function refresh({ simulateLoad } = {}) {
    if (!simulateLoad) { renderAll(); return; }
    showLoading();
    setTimeout(renderAll, 380);
  }

  /* Header search stays on this page and filters the requests table */
  EW.shell.onSearch = (query) => {
    state.query = query;
    document.getElementById("requestSearch").value = query;
    renderRequests();
    document.getElementById("requestsPanel").scrollIntoView({ behavior: "smooth", block: "start" });
  };

  /* ---------- Initial load ---------- */
  renderPeriodFilter();
  showLoading();
  EW.store.mockService.fetchRequests()
    .then(requests => { state.requests = requests; renderAll(); })
    .catch(() => {
      cardsEl.innerHTML = "";
      document.getElementById("requestsTable").innerHTML = EmptyState({
        icon: "alert", title: "Couldn't load the dashboard", message: "Reload the page to try again."
      });
    });
})();
