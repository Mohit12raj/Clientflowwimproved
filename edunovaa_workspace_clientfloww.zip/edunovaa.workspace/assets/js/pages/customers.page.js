/* ==========================================================
   Page: Customers
   - Search, status filter (with counts) and service filter
   - Sortable customer table with loading + empty states
   - Add customer modal: validation, saving and success states
   - Customer details open in a side drawer on row click
   Deep links: ?id=CUS-1001  ?q=delhi  ?status=Pending  ?new=1
   ========================================================== */
(function () {
  EW.shell.mount({ active: "customers" });
  const { DataTable, FilterTabs, SearchInput, StatusBadge, EmptyState, Button, Field, Modal } = EW.ui;
  const { escapeHTML, initials, avatarColor, matchesQuery, debounce, getQueryParam, setQueryParam } = EW.utils;
  const fmt = EW.format;

  const initialStatus = getQueryParam("status");
  const state = {
    customers: [],
    query: getQueryParam("q") || "",
    status: ["All", ...EW.data.customerStatuses].includes(initialStatus) ? initialStatus : "All",
    service: "",
    highlightId: null
  };

  /* ---------- Header + toolbar ---------- */
  document.getElementById("headerActions").innerHTML =
    Button({ label: "Add customer", icon: "plus", attrs: { "data-open-add": "" } });

  document.getElementById("customerToolbar").innerHTML = `
    ${SearchInput({ id: "customerSearch", label: "Search customers", placeholder: "Search name, company, email, phone or city", value: state.query })}
    <div id="customerStatusFilter"></div>
    <label class="sr-only" for="serviceFilter">Filter by service</label>
    <select class="control control-compact" id="serviceFilter">
      <option value="">All services</option>
      ${EW.data.services.map(s => `<option>${escapeHTML(s)}</option>`).join("")}
    </select>`;
  EW.shell.setSearchValue(state.query);

  const searchInput = document.getElementById("customerSearch");
  const statusFilterEl = document.getElementById("customerStatusFilter");
  const countEl = document.getElementById("customerCount");

  /* ---------- Table ---------- */
  const table = new DataTable(document.getElementById("customerTable"), {
    caption: "Customers",
    sort: { key: "joinedOn", dir: "desc" },
    skeletonRows: 8,
    rowLabel: (c) => `View details for ${c.name}`,
    rowClass: (c) => (c.id === state.highlightId ? "is-highlighted" : ""),
    onRowClick: (c) => openDetails(c.id),
    columns: [
      { key: "name", label: "Customer", sortable: true, render: (c) => `
          <div class="cell-person">
            <span class="avatar" style="background:${avatarColor(c.name)}">${initials(c.name)}</span>
            <div class="cell-stack"><strong>${escapeHTML(c.name)}${c.isNew ? `<span class="new-pill">New</span>` : ""}</strong>
            <span class="cell-sub">${escapeHTML(c.company || "Individual")}${c.city ? `, ${escapeHTML(c.city)}` : ""}</span></div>
          </div>` },
      { key: "email", label: "Contact", hideBelow: "md", render: (c) => `
          <div class="cell-stack"><span>${escapeHTML(c.email)}</span><span class="cell-sub num">${escapeHTML(c.phone)}</span></div>` },
      { key: "service", label: "Service", sortable: true, hideBelow: "sm", render: (c) => `<span class="cell-muted">${escapeHTML(c.service || "Not set")}</span>` },
      { key: "status", label: "Status", sortable: true, render: (c) => StatusBadge(c.status) },
      { key: "joinedOn", label: "Customer since", sortable: true, hideBelow: "lg", render: (c) => `<span class="cell-muted">${fmt.date(c.joinedOn)}</span>` },
      { key: "totalBilled", label: "Total billed", sortable: true, align: "right", hideBelow: "xs", render: (c) => `<span class="num strong">${c.totalBilled ? fmt.inr(c.totalBilled) : "—"}</span>` }
    ],
    emptyState: () => {
      if (!state.customers.length) {
        return EmptyState({ icon: "users", title: "No customers yet", message: "Add your first customer to start tracking their services.", actions: [{ label: "Add customer", action: "add", variant: "primary", icon: "plus" }] });
      }
      const parts = [];
      if (state.query) parts.push(`matching “${state.query}”`);
      if (state.status !== "All") parts.push(`with status ${state.status}`);
      if (state.service) parts.push(`using ${state.service}`);
      return EmptyState({
        icon: "filterOff", title: "No customers found",
        message: `There are no customers ${parts.join(", ")}. Try a different search or clear the filters.`,
        actions: [{ label: "Clear filters", action: "clear", icon: "x" }, { label: "Add customer", action: "add", icon: "plus" }]
      });
    },
    onAction: (action) => {
      if (action === "add") addForm.open();
      if (action === "clear") clearFilters();
    }
  });

  function filteredCustomers() {
    const searched = state.customers
      .filter(c => !state.service || c.service === state.service)
      .filter(c => matchesQuery([c.name, c.company, c.email, c.phone, c.city, c.id, c.service], state.query));
    return { searched, visible: state.status === "All" ? searched : searched.filter(c => c.status === state.status) };
  }

  function render() {
    const { searched, visible } = filteredCustomers();
    statusFilterEl.innerHTML = FilterTabs({
      label: "Filter customers by status", value: state.status,
      options: ["All", ...EW.data.customerStatuses].map(s => ({
        value: s, label: s, count: s === "All" ? searched.length : searched.filter(c => c.status === s).length
      }))
    });
    countEl.textContent = `Showing ${visible.length} of ${fmt.plural(state.customers.length, "customer")}`;
    table.setRows(visible);
  }

  function clearFilters() {
    state.query = ""; state.status = "All"; state.service = "";
    searchInput.value = ""; document.getElementById("serviceFilter").value = "";
    EW.shell.setSearchValue("");
    setQueryParam("q", ""); setQueryParam("status", "");
    render();
  }

  /* ---------- Search & filter events ---------- */
  searchInput.addEventListener("input", debounce(() => {
    state.query = searchInput.value.trim();
    setQueryParam("q", state.query);
    EW.shell.setSearchValue(state.query);
    render();
  }, 180));

  FilterTabs.bind(statusFilterEl, (value) => {
    state.status = value;
    setQueryParam("status", value === "All" ? "" : value);
    render();
  });

  document.getElementById("serviceFilter").addEventListener("change", (e) => { state.service = e.target.value; render(); });

  EW.shell.onSearch = (query) => {  // header search filters in place
    state.query = query;
    searchInput.value = query;
    setQueryParam("q", query);
    render();
  };

  /* ==========================================================
     Customer details (drawer)
     ========================================================== */
  const detailDrawer = new Modal({ id: "customerDetails", variant: "drawer", size: "lg", onClose: () => setQueryParam("id", "") });

  function openDetails(id) {
    const c = EW.store.getCustomer(id);
    if (!c) { EW.ui.toast(`No customer found with ID ${id}.`, { tone: "error" }); setQueryParam("id", ""); return; }
    setQueryParam("id", c.id);
    const requests = EW.store.getRequestsFor(c.id).sort((a, b) => b.requestedOn.localeCompare(a.requestedOn));
    const open = requests.filter(r => r.status === "Pending" || r.status === "In progress").length;
    const fact = (icon, label, value) => `<div class="fact">${EW.icons[icon]}<div><dt>${label}</dt><dd>${value}</dd></div></div>`;

    detailDrawer.setContent({
      header: `
        <div class="detail-hero">
          <span class="avatar avatar-lg" style="background:${avatarColor(c.name)}">${initials(c.name)}</span>
          <div>
            <h2 id="customerDetails-title">${escapeHTML(c.name)}</h2>
            <p>${escapeHTML(c.company || "Individual")} <span class="id-tag">${c.id}</span></p>
            ${StatusBadge(c.status)}
          </div>
        </div>`,
      body: `
        <div class="detail-totals">
          <div><span>Total billed</span><strong class="num">${fmt.inr(c.totalBilled)}</strong></div>
          <div><span>Open requests</span><strong class="num">${open}</strong></div>
          <div><span>All requests</span><strong class="num">${requests.length}</strong></div>
        </div>

        <section class="detail-section">
          <h3>Contact</h3>
          <dl class="facts">
            ${fact("mail", "Email", `<a href="mailto:${escapeHTML(c.email)}">${escapeHTML(c.email)}</a>`)}
            ${fact("phone", "Phone", `<a href="tel:${escapeHTML(c.phone.replace(/\s/g, ""))}">${escapeHTML(c.phone)}</a>`)}
            ${fact("mapPin", "City", escapeHTML(c.city || "Not added"))}
            ${fact("briefcase", "Service", escapeHTML(c.service || "Not set"))}
            ${fact("calendar", "Customer since", fmt.date(c.joinedOn))}
          </dl>
        </section>

        <section class="detail-section">
          <h3>Service requests</h3>
          ${requests.length ? `<ol class="timeline">${requests.map(r => `
            <li>
              <div class="timeline-main">
                <strong>${escapeHTML(r.title)}</strong>
                <span class="cell-sub"><span class="id-tag">${r.id}</span>${fmt.relativeDate(r.requestedOn)}${r.amount ? `, ${fmt.inr(r.amount)}` : ""}</span>
              </div>
              <div class="timeline-badges">${StatusBadge(r.priority, "priority")}${StatusBadge(r.status, "request")}</div>
            </li>`).join("")}</ol>`
          : EmptyState({ icon: "inbox", title: "No service requests yet", message: "Requests this customer raises will be listed here.", compact: true })}
        </section>

        <section class="detail-section">
          <h3>Notes</h3>
          <p class="notes">${c.notes ? escapeHTML(c.notes) : "No notes added."}</p>
        </section>`,
      footer:
        Button({ label: "Call", icon: "phone", variant: "secondary", href: "tel:" + c.phone.replace(/\s/g, "") }) +
        Button({ label: "Email customer", icon: "mail", href: "mailto:" + c.email })
    });
    detailDrawer.open();
  }

  /* ==========================================================
     Add customer (modal form)
     ========================================================== */
  const { rules } = EW.validate;
  const addSchema = {
    name:   [rules.required("Enter the customer's full name."), rules.minLength(2, "Name must be at least 2 characters.")],
    email:  [rules.required("Enter an email address."), rules.email(), rules.unique(EW.store.emailExists, "A customer with this email already exists.")],
    phone:  [rules.required("Enter a phone number."), rules.phone()],
    status: [rules.required("Choose a status.")]
  };

  const formHTML = `
    <form id="addCustomerForm" novalidate>
      <div class="form-alert form-alert-error" id="addFormAlert" role="alert" hidden></div>
      <div class="form-grid">
        ${Field({ name: "name", label: "Full name", required: true, placeholder: "e.g. Aarav Sharma", autocomplete: "off" })}
        ${Field({ name: "email", label: "Email", type: "email", required: true, placeholder: "name@company.com", autocomplete: "off", inputmode: "email" })}
        ${Field({ name: "phone", label: "Phone", type: "tel", required: true, placeholder: "+91 98765 43210", hint: "10-digit mobile, with or without +91", inputmode: "tel" })}
        ${Field({ name: "status", label: "Status", type: "select", required: true, options: [{ value: "", label: "Choose a status" }, ...EW.data.customerStatuses] })}
        ${Field({ name: "company", label: "Company", placeholder: "e.g. BrightPath Academy" })}
        ${Field({ name: "service", label: "Service", type: "select", options: [{ value: "", label: "Not decided yet" }, ...EW.data.services] })}
      </div>
    </form>`;
  const formFooter =
    Button({ label: "Cancel", variant: "secondary", attrs: { "data-close": "" } }) +
    Button({ label: "Save customer", type: "submit", attrs: { form: "addCustomerForm", id: "saveCustomerBtn" } });

  const addForm = {
    modal: new Modal({ id: "addCustomer", size: "md" }),

    open() {
      this.modal.setContent({ title: "Add customer", description: "Fields marked * are required.", body: formHTML, footer: formFooter });
      this.bind();
      setQueryParam("new", "");
      this.modal.open();
    },

    showSuccess(customer) {
      this.modal.setContent({
        title: "Customer added",
        description: "",
        body: `
          <div class="success-state" role="status">
            <div class="success-icon">${EW.icons.check}</div>
            <h3>${escapeHTML(customer.name)} is now a customer</h3>
            <p>Saved as <span class="id-tag">${customer.id}</span> with status ${StatusBadge(customer.status)}. You'll find them at the top of the list.</p>
          </div>`,
        footer:
          Button({ label: "Add another", variant: "secondary", icon: "plus", attrs: { "data-add-another": "" } }) +
          Button({ label: "View details", attrs: { "data-view-new": customer.id, "data-autofocus": "" } })
      });
      this.modal.dialog.querySelector("[data-view-new]").focus();
    },

    bind() {
      const form = document.getElementById("addCustomerForm");
      const alert = document.getElementById("addFormAlert");

      const check = (name) => {
        const error = EW.validate.field(form.elements[name].value, addSchema[name]);
        Field.setError(form, name, error);
        Field.setValid(form, name, !error && form.elements[name].value.trim());
        return error;
      };

      form.addEventListener("focusout", (e) => {
        const name = e.target.name;
        if (addSchema[name] && e.target.value.trim()) check(name);
      });
      form.addEventListener("input", (e) => {
        const field = e.target.closest(".field");
        if (field && field.classList.contains("has-error")) check(e.target.name);
        alert.hidden = true;
      });
      form.addEventListener("change", (e) => { if (e.target.tagName === "SELECT" && addSchema[e.target.name]) check(e.target.name); });

      form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const values = Field.values(form);
        const { valid, errors } = EW.validate.form(values, addSchema);
        Object.keys(addSchema).forEach(name => { Field.setError(form, name, errors[name]); Field.setValid(form, name, !errors[name]); });

        if (!valid) {
          const n = Object.keys(errors).length;
          alert.hidden = false;
          alert.innerHTML = EW.icons.alert + `<span>Fix ${n === 1 ? "the highlighted field" : `the ${n} highlighted fields`} before saving.</span>`;
          form.querySelector(".has-error .control")?.focus();
          return;
        }

        const saveBtn = document.getElementById("saveCustomerBtn");
        Button.setLoading(saveBtn, true, "Saving…");
        form.querySelectorAll(".control").forEach(el => { el.disabled = true; });
        try {
          const customer = await EW.store.mockService.saveCustomer(values);
          state.customers = EW.store.getCustomers();
          state.highlightId = customer.id;
          state.query = ""; state.status = "All"; state.service = "";
          searchInput.value = ""; document.getElementById("serviceFilter").value = "";
          table.sort = { key: "joinedOn", dir: "desc" };
          render();
          EW.shell.refresh();
          EW.ui.toast(`${customer.name} added to customers`);
          this.showSuccess(customer);
        } catch (err) {
          Button.setLoading(saveBtn, false);
          form.querySelectorAll(".control").forEach(el => { el.disabled = false; });
          alert.hidden = false;
          alert.innerHTML = EW.icons.alert + "<span>The customer couldn't be saved. Try again.</span>";
        }
      });
    }
  };

  addForm.modal.el.addEventListener("click", (e) => {
    if (e.target.closest("[data-add-another]")) addForm.open();
    const view = e.target.closest("[data-view-new]");
    if (view) { addForm.modal.close(); openDetails(view.dataset.viewNew); }
  });
  document.addEventListener("click", (e) => { if (e.target.closest("[data-open-add]")) addForm.open(); });

  /* ---------- Initial load ---------- */
  table.setLoading(true);
  countEl.textContent = "Loading customers…";
  EW.store.mockService.fetchCustomers()
    .then(customers => {
      state.customers = customers;
      render();
      const deepId = getQueryParam("id");
      if (deepId) openDetails(deepId);
      if (getQueryParam("new")) addForm.open();
    })
    .catch(() => {
      document.getElementById("customerTable").innerHTML = EmptyState({ icon: "alert", title: "Couldn't load customers", message: "Reload the page to try again." });
    });
})();
