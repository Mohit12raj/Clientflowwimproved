/* ==========================================================
   Page: Login
   - Email format + required password validation
   - Errors shown on blur, on submit, and in a summary alert
   - Loading and success states, then redirect to Dashboard
   - No real authentication (see core/auth.js)
   ========================================================== */
(function () {
  EW.auth.redirectIfSignedIn();

  const { Field, Button } = EW.ui;
  const { rules } = EW.validate;
  const form = document.getElementById("loginForm");

  /* ---------- Build the form from reusable components ---------- */
  form.innerHTML = `
    <div class="form-alert" id="formAlert" role="alert" hidden></div>
    ${Field({ name: "email", label: "Work email", type: "email", required: true, placeholder: "name@edunovaa.com", autocomplete: "username", inputmode: "email" })}
    ${Field({
      name: "password", label: "Password", type: "password", required: true, placeholder: "Enter your password", autocomplete: "current-password",
      suffix: Button({ label: "Show password", icon: "eye", iconOnly: true, variant: "ghost", className: "pw-toggle", attrs: { "data-pw-toggle": "" } })
    })}
    <p class="caps-hint" id="capsHint" hidden>${EW.icons.lock}<span>Caps Lock is on</span></p>
    <div class="login-row">
      <label class="check"><input type="checkbox" id="remember"> Keep me signed in</label>
      <button type="button" class="link-btn" id="forgotLink">Forgot password?</button>
    </div>
    ${Button({ label: "Sign in", type: "submit", className: "btn-block", attrs: { id: "loginBtn" } })}
  `;

  const alertBox = document.getElementById("formAlert");
  const loginBtn = document.getElementById("loginBtn");
  const emailInput = form.elements.email;
  const passwordInput = form.elements.password;

  const schema = {
    email: [rules.required("Enter your email address."), rules.email("That doesn't look like an email. Use the format name@company.com.")],
    password: [rules.required("Enter your password.")]
  };

  /* Show a note after sign-out */
  try {
    if (sessionStorage.getItem("ew_signed_out")) {
      sessionStorage.removeItem("ew_signed_out");
      showAlert("You've signed out. Sign in again to continue.", "info");
    }
  } catch (e) {}

  function showAlert(message, tone = "error") {
    alertBox.hidden = !message;
    alertBox.className = `form-alert form-alert-${tone}`;
    alertBox.innerHTML = message ? EW.icons[tone === "success" ? "checkCircle" : "alert"] + `<span>${EW.utils.escapeHTML(message)}</span>` : "";
  }

  function validateField(name) {
    const error = EW.validate.field(form.elements[name].value, schema[name]);
    Field.setError(form, name, error);
    return !error;
  }

  /* Validate when leaving a field; clear the error as soon as it's fixed */
  ["email", "password"].forEach(name => {
    const input = form.elements[name];
    input.addEventListener("blur", () => { if (input.value) validateField(name); });
    input.addEventListener("input", () => {
      if (input.closest(".field").classList.contains("has-error")) validateField(name);
      if (!alertBox.hidden) showAlert("");
    });
  });

  /* Show / hide password */
  form.querySelector("[data-pw-toggle]").addEventListener("click", (e) => {
    const btn = e.currentTarget;
    const show = passwordInput.type === "password";
    passwordInput.type = show ? "text" : "password";
    btn.innerHTML = EW.icons[show ? "eyeOff" : "eye"] + `<span class="sr-only">${show ? "Hide" : "Show"} password</span>`;
    passwordInput.focus();
  });

  /* Caps Lock warning */
  const capsHint = document.getElementById("capsHint");
  passwordInput.addEventListener("keyup", (e) => { capsHint.hidden = !(e.getModifierState && e.getModifierState("CapsLock")); });
  passwordInput.addEventListener("blur", () => { capsHint.hidden = true; });

  /* Submit */
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    showAlert("");
    const okEmail = validateField("email");
    const okPassword = validateField("password");
    if (!okEmail || !okPassword) {
      const count = [okEmail, okPassword].filter(v => !v).length;
      showAlert(count === 2 ? "Fix the 2 highlighted fields to sign in." : "Fix the highlighted field to sign in.");
      form.querySelector(".has-error .control")?.focus();
      return;
    }

    Button.setLoading(loginBtn, true, "Signing in…");
    setTimeout(() => {  // simulated request, so the loading state is visible
      const result = EW.auth.login(emailInput.value, passwordInput.value, document.getElementById("remember").checked);
      if (result.ok) {
        loginBtn.innerHTML = EW.icons.check + "<span>Signed in</span>";
        loginBtn.classList.add("is-success");
        showAlert("Signed in. Opening your dashboard…", "success");
        setTimeout(() => window.location.replace("dashboard.html"), 500);
      } else {
        Button.setLoading(loginBtn, false);
        showAlert(result.message);
        passwordInput.select();
      }
    }, 650);
  });

  document.getElementById("fillDemo").addEventListener("click", () => {
    emailInput.value = EW.auth.demoUser.email;
    passwordInput.value = EW.auth.demoUser.password;
    Field.clearErrors(form);
    showAlert("");
    loginBtn.focus();
  });

  document.getElementById("forgotLink").addEventListener("click", () => {
    showAlert("Password reset isn't available in the prototype. Ask your workspace admin to reset it.", "info");
  });
})();
