/* ==========================================================
   Component: Modal (dialog or side drawer)
   const m = new EW.ui.Modal({ id, title, description, size, variant, body, footer });
   m.open(); m.close(); m.setContent({ title, description, body, footer });
   EW.ui.Modal.confirm({ title, message, confirmLabel, tone }) -> Promise<boolean>
   Handles: focus trap, Esc to close, backdrop click, focus return.
   ========================================================== */
window.EW = window.EW || {};
EW.ui = EW.ui || {};

EW.ui.Modal = class Modal {
  static stack = [];

  constructor({ id, title = "", description = "", size = "md", variant = "dialog", body = "", footer = "", header, onClose } = {}) {
    this.id = id || "modal-" + Math.random().toString(36).slice(2, 8);
    this.onClose = onClose;
    this.el = document.createElement("div");
    this.el.className = `overlay overlay-${variant}`;
    this.el.id = this.id;
    this.el.innerHTML = `
      <div class="dialog dialog-${size}" role="dialog" aria-modal="true" aria-labelledby="${this.id}-title" tabindex="-1">
        <div class="dialog-header">
          <div class="dialog-heading"></div>
          ${EW.ui.Button({ label: "Close", icon: "x", iconOnly: true, variant: "ghost", attrs: { "data-close": "" } })}
        </div>
        <div class="dialog-body"></div>
        <div class="dialog-footer"></div>
      </div>`;
    document.body.appendChild(this.el);

    this.dialog  = this.el.querySelector(".dialog");
    this.heading = this.el.querySelector(".dialog-heading");
    this.bodyEl  = this.el.querySelector(".dialog-body");
    this.footerEl = this.el.querySelector(".dialog-footer");
    this.setContent({ title, description, body, footer, header });

    this.el.addEventListener("mousedown", (e) => { if (e.target === this.el) this.close(); });
    this.el.addEventListener("click", (e) => { if (e.target.closest("[data-close]")) this.close(); });
    this.el.addEventListener("keydown", (e) => this.trapFocus(e));
  }

  setContent({ title, description, body, footer, header } = {}) {
    if (header !== undefined) this.heading.innerHTML = header;
    else if (title !== undefined) {
      this.heading.innerHTML = `<h2 id="${this.id}-title">${EW.utils.escapeHTML(title)}</h2>` +
        (description ? `<p>${EW.utils.escapeHTML(description)}</p>` : "");
    }
    if (body !== undefined) this.bodyEl.innerHTML = body;
    if (footer !== undefined) {
      this.footerEl.innerHTML = footer;
      this.footerEl.hidden = !footer;
    }
  }

  open() {
    if (!this.el.classList.contains("is-open")) {
      this.returnFocus = document.activeElement;
      Modal.stack.push(this);
    }
    this.el.classList.add("is-open");
    document.body.classList.add("has-overlay");
    requestAnimationFrame(() => {
      const first = this.dialog.querySelector("input:not([type=hidden]), select, textarea, [data-autofocus]");
      (first || this.dialog).focus();
    });
  }

  close() {
    if (!this.el.classList.contains("is-open")) return;
    this.el.classList.remove("is-open");
    Modal.stack = Modal.stack.filter(m => m !== this);
    if (!Modal.stack.length) document.body.classList.remove("has-overlay");
    if (this.returnFocus && document.contains(this.returnFocus)) this.returnFocus.focus();
    if (this.onClose) this.onClose();
  }

  trapFocus(e) {
    if (e.key !== "Tab") return;
    const focusable = Array.from(this.dialog.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )).filter(el => el.offsetParent !== null);
    if (!focusable.length) return;
    const first = focusable[0], last = focusable[focusable.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }

  /** Small yes/no dialog, e.g. before signing out */
  static confirm({ title, message, confirmLabel = "Confirm", cancelLabel = "Cancel", tone = "primary" }) {
    return new Promise(resolve => {
      let answered = false;
      const modal = new Modal({
        title, size: "sm",
        body: `<p class="confirm-text">${EW.utils.escapeHTML(message)}</p>`,
        footer: EW.ui.Button({ label: cancelLabel, variant: "secondary", attrs: { "data-close": "", "data-autofocus": "" } }) +
                EW.ui.Button({ label: confirmLabel, variant: tone, attrs: { "data-confirm": "" } }),
        onClose: () => { if (!answered) resolve(false); setTimeout(() => modal.el.remove(), 250); }
      });
      modal.el.addEventListener("click", (e) => {
        if (e.target.closest("[data-confirm]")) { answered = true; resolve(true); modal.close(); }
      });
      modal.open();
    });
  }
};

/* Esc closes only the top-most overlay */
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && EW.ui.Modal.stack.length) {
    EW.ui.Modal.stack[EW.ui.Modal.stack.length - 1].close();
  }
});
