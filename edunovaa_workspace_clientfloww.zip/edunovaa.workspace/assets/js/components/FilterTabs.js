/* ==========================================================
   Component: FilterTabs (segmented control)
   Used for the dashboard period and every status filter.
   EW.ui.FilterTabs({ options:[{value,label,count}], value, label })
   EW.ui.FilterTabs.bind(container, onChange)
   ========================================================== */
window.EW = window.EW || {};
EW.ui = EW.ui || {};

EW.ui.FilterTabs = (() => {
  const { escapeHTML, cx } = EW.utils;

  function FilterTabs({ options = [], value, label = "Filter", variant } = {}) {
    return `
      <div class="${cx("filter-tabs", variant && `filter-tabs-${variant}`)}" role="group" aria-label="${escapeHTML(label)}">
        ${options.map(o => {
          const active = o.value === value;
          return `<button type="button" data-value="${escapeHTML(o.value)}" class="${active ? "is-active" : ""}" aria-pressed="${active}">
            ${escapeHTML(o.label)}${o.count !== undefined ? `<span class="count">${o.count}</span>` : ""}
          </button>`;
        }).join("")}
      </div>`;
  }

  /** Event delegation: survives re-rendering of the buttons */
  FilterTabs.bind = (container, onChange) => {
    container.addEventListener("click", (e) => {
      const btn = e.target.closest(".filter-tabs button[data-value]");
      if (btn && container.contains(btn)) onChange(btn.dataset.value);
    });
    container.addEventListener("keydown", (e) => {
      if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
      const buttons = Array.from(container.querySelectorAll(".filter-tabs button"));
      const i = buttons.indexOf(document.activeElement);
      if (i < 0) return;
      e.preventDefault();
      buttons[(i + (e.key === "ArrowRight" ? 1 : -1) + buttons.length) % buttons.length].focus();
    });
  };

  return FilterTabs;
})();
