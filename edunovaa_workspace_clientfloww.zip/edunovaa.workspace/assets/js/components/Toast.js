/* ==========================================================
   Component: Toast
   EW.ui.toast("Customer added")                -> success
   EW.ui.toast("Could not save", { tone: "error" })
   ========================================================== */
window.EW = window.EW || {};
EW.ui = EW.ui || {};

EW.ui.toast = function toast(message, { tone = "success", duration = 3600 } = {}) {
  let region = document.querySelector(".toast-region");
  if (!region) {
    region = document.createElement("div");
    region.className = "toast-region";
    region.setAttribute("role", "status");
    region.setAttribute("aria-live", "polite");
    document.body.appendChild(region);
  }
  const icon = { success: "checkCircle", error: "alert", info: "alert" }[tone] || "checkCircle";
  const el = document.createElement("div");
  el.className = `toast toast-${tone}`;
  el.innerHTML = EW.icons[icon] + `<span>${EW.utils.escapeHTML(message)}</span>`;
  region.appendChild(el);
  setTimeout(() => { el.classList.add("is-leaving"); setTimeout(() => el.remove(), 250); }, duration);
};
