/* ==========================================================
   Component: Input / Field
   EW.ui.Field({ name, label, type, required, options, hint })
     -> label + input/select/textarea + error slot, wired for a11y
   EW.ui.Field.setError(root, name, message)
   EW.ui.Field.clearErrors(root)
   EW.ui.Field.values(form)
   EW.ui.SearchInput({ id, label, placeholder })
   ========================================================== */
window.EW = window.EW || {};
EW.ui = EW.ui || {};

(() => {
  const { escapeHTML, attrs, cx } = EW.utils;

  function control({ name, id, type, placeholder, options, autocomplete, value, required, inputmode }) {
    const common = attrs({ id, name, "aria-describedby": `${id}-msg`, "aria-required": required ? "true" : false });
    if (type === "select") {
      const opts = (options || []).map(o => {
        const opt = typeof o === "string" ? { value: o, label: o } : o;
        return `<option value="${escapeHTML(opt.value)}"${opt.value === value ? " selected" : ""}>${escapeHTML(opt.label)}</option>`;
      }).join("");
      return `<select class="control"${common}>${opts}</select>`;
    }
    if (type === "textarea") {
      return `<textarea class="control"${common}${attrs({ placeholder, rows: 3 })}>${escapeHTML(value || "")}</textarea>`;
    }
    return `<input class="control"${common}${attrs({ type, placeholder, autocomplete, value, inputmode })}>`;
  }

  function Field({ name, label, type = "text", required = false, placeholder, options, hint, autocomplete, value, span, inputmode, suffix } = {}) {
    const id = `f-${name}`;
    return `
      <div class="${cx("field", span === 2 && "span-2")}" data-field="${escapeHTML(name)}">
        <label for="${id}">${escapeHTML(label)}${required ? `<span class="req" aria-hidden="true">*</span>` : `<span class="opt">optional</span>`}</label>
        <div class="control-wrap">
          ${control({ name, id, type, placeholder, options, autocomplete, value, required, inputmode })}
          ${suffix || ""}
        </div>
        <p class="field-msg" id="${id}-msg" data-hint="${escapeHTML(hint || "")}">${escapeHTML(hint || "")}</p>
      </div>`;
  }

  Field.setError = (root, name, message) => {
    const field = root.querySelector(`.field[data-field="${name}"]`);
    if (!field) return;
    const input = field.querySelector(".control");
    const msg = field.querySelector(".field-msg");
    field.classList.toggle("has-error", Boolean(message));
    input.setAttribute("aria-invalid", message ? "true" : "false");
    msg.innerHTML = message ? EW.icons.alert + `<span>${escapeHTML(message)}</span>` : escapeHTML(msg.dataset.hint || "");
  };

  Field.setValid = (root, name, valid) => {
    const field = root.querySelector(`.field[data-field="${name}"]`);
    if (field) field.classList.toggle("is-valid", Boolean(valid));
  };

  Field.clearErrors = (root) => {
    root.querySelectorAll(".field").forEach(f => { Field.setError(root, f.dataset.field, ""); f.classList.remove("is-valid"); });
  };

  Field.values = (form) => {
    const data = Object.fromEntries(new FormData(form).entries());
    Object.keys(data).forEach(k => { data[k] = String(data[k]).trim(); });
    return data;
  };

  function SearchInput({ id, label = "Search", placeholder = "Search", value = "" } = {}) {
    return `
      <div class="search-input">
        ${EW.icons.search}
        <label for="${id}" class="sr-only">${escapeHTML(label)}</label>
        <input class="control" type="search" id="${id}" placeholder="${escapeHTML(placeholder)}" value="${escapeHTML(value)}" autocomplete="off">
      </div>`;
  }

  EW.ui.Field = Field;
  EW.ui.SearchInput = SearchInput;
})();
