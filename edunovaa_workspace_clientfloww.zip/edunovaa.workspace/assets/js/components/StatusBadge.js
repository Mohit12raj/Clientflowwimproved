/* ==========================================================
   Component: StatusBadge
   EW.ui.StatusBadge("Active")                 -> customer status
   EW.ui.StatusBadge("In progress", "request") -> request status
   EW.ui.StatusBadge("High", "priority")       -> priority
   ========================================================== */
window.EW = window.EW || {};
EW.ui = EW.ui || {};

EW.ui.StatusBadge = (() => {
  const TONES = {
    customer: { Active: "positive", Pending: "waiting", Inactive: "neutral" },
    request:  { Pending: "waiting", "In progress": "working", Completed: "positive", Cancelled: "neutral" },
    priority: { High: "urgent", Medium: "working", Low: "neutral" }
  };

  return function StatusBadge(value, kind = "customer") {
    const tone = (TONES[kind] || {})[value] || "neutral";
    const shape = kind === "priority" ? "badge-outline" : "badge-dot";
    return `<span class="badge ${shape} tone-${tone}">${EW.utils.escapeHTML(value || "—")}</span>`;
  };
})();
