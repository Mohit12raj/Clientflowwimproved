/* ==========================================================
   Component: DataTable
   One table implementation for every list in the app:
   sorting, loading skeleton rows, empty states, row click.

   const table = new EW.ui.DataTable(container, {
     columns: [{ key, label, sortable, sortValue(row), render(row), align, hideBelow }],
     rowKey: "id",
     rowLabel: (row) => "Open …",
     rowClass: (row) => "",
     sort: { key: "date", dir: "desc" },
     emptyState: () => EW.ui.EmptyState({...}),
     onRowClick: (row) => {},
     onAction: (action) => {}   // buttons inside the empty state
   });
   table.setLoading(true); table.setRows(rows);
   ========================================================== */
window.EW = window.EW || {};
EW.ui = EW.ui || {};

EW.ui.DataTable = class DataTable {
  constructor(container, options) {
    this.container = container;
    this.options = { rowKey: "id", skeletonRows: 6, ...options };
    this.sort = options.sort ? { ...options.sort } : null;
    this.rows = [];
    this.loading = false;
    this.container.classList.add("data-table");
    this.bindEvents();
  }

  /* ---------- Public API ---------- */
  setRows(rows) { this.rows = rows.slice(); this.loading = false; this.expanded = false; this.render(); }
  setLoading(loading = true) { this.loading = loading; this.render(); }
  getSortedRows() {
    if (!this.sort) return this.rows;
    const column = this.options.columns.find(c => c.key === this.sort.key);
    if (!column) return this.rows;
    const value = column.sortValue || ((row) => row[column.key]);
    const dir = this.sort.dir === "asc" ? 1 : -1;
    return this.rows.slice().sort((a, b) => EW.utils.compare(value(a), value(b)) * dir);
  }

  /* ---------- Rendering ---------- */
  headerCell(col) {
    const { cx, escapeHTML } = EW.utils;
    const classes = cx(col.align === "right" && "align-right", col.hideBelow && `hide-below-${col.hideBelow}`);
    if (!col.sortable) return `<th scope="col" class="${classes}">${escapeHTML(col.label)}</th>`;
    const active = this.sort && this.sort.key === col.key;
    const ariaSort = active ? (this.sort.dir === "asc" ? "ascending" : "descending") : "none";
    const icon = active ? (this.sort.dir === "asc" ? EW.icons.chevronUp : EW.icons.chevronDown) : EW.icons.sort;
    return `
      <th scope="col" class="${classes}" aria-sort="${ariaSort}">
        <button type="button" class="${cx("sort-btn", active && "is-active")}" data-sort="${col.key}">
          <span>${escapeHTML(col.label)}</span>${icon}
        </button>
      </th>`;
  }

  bodyCell(col, row) {
    const classes = EW.utils.cx(col.align === "right" && "align-right", col.hideBelow && `hide-below-${col.hideBelow}`, col.className);
    const content = col.render ? col.render(row) : EW.utils.escapeHTML(row[col.key]);
    return `<td class="${classes}">${content}</td>`;
  }

  skeletonRow() {
    return `<tr class="skeleton-row" aria-hidden="true">${this.options.columns.map(col =>
      `<td class="${col.hideBelow ? `hide-below-${col.hideBelow}` : ""}"><span class="skeleton skeleton-text" style="width:${40 + Math.round(Math.random() * 45)}%"></span></td>`
    ).join("")}</tr>`;
  }

  render() {
    const { columns, rowKey, rowLabel, rowClass, onRowClick, emptyState, caption } = this.options;
    const allRows = this.getSortedRows();
    const { pageSize } = this.options;
    const limited = pageSize && !this.expanded && allRows.length > pageSize;
    const rows = limited ? allRows.slice(0, pageSize) : allRows;
    const clickable = typeof onRowClick === "function";

    let bodyHTML;
    if (this.loading) {
      bodyHTML = Array.from({ length: this.options.skeletonRows }, () => this.skeletonRow()).join("");
    } else {
      bodyHTML = rows.map(row => `
        <tr class="${EW.utils.cx(clickable && "is-clickable", rowClass && rowClass(row))}"
            data-key="${EW.utils.escapeHTML(row[rowKey])}"
            ${clickable ? `tabindex="0" aria-label="${EW.utils.escapeHTML(rowLabel ? rowLabel(row) : "Open row")}"` : ""}>
          ${columns.map(col => this.bodyCell(col, row)).join("")}
        </tr>`).join("");
    }

    const showEmpty = !this.loading && rows.length === 0;
    this.container.innerHTML = `
      <div class="table-scroll" ${this.loading ? 'aria-busy="true"' : ""}>
        <table class="table">
          ${caption ? `<caption class="sr-only">${EW.utils.escapeHTML(caption)}</caption>` : ""}
          <thead><tr>${columns.map(col => this.headerCell(col)).join("")}</tr></thead>
          <tbody>${showEmpty ? "" : bodyHTML}</tbody>
        </table>
      </div>
      ${showEmpty && emptyState ? emptyState() : ""}
      ${limited ? `<div class="table-more"><button type="button" class="btn btn-ghost" data-show-all>Show all ${allRows.length}</button></div>` : ""}
      ${this.loading ? `<span class="sr-only" role="status">Loading…</span>` : ""}`;
  }

  /* ---------- Events (delegated once) ---------- */
  bindEvents() {
    const findRow = (target) => {
      const tr = target.closest("tr[data-key]");
      return tr ? this.rows.find(r => String(r[this.options.rowKey]) === tr.dataset.key) : null;
    };

    this.container.addEventListener("click", (e) => {
      const sortBtn = e.target.closest("[data-sort]");
      if (sortBtn) {
        const key = sortBtn.dataset.sort;
        this.sort = this.sort && this.sort.key === key
          ? { key, dir: this.sort.dir === "asc" ? "desc" : "asc" }
          : { key, dir: "asc" };
        this.render();
        this.container.querySelector(`[data-sort="${key}"]`)?.focus();
        return;
      }
      if (e.target.closest("[data-show-all]")) {
        this.expanded = true;
        this.render();
        this.container.querySelectorAll("tbody tr")[this.options.pageSize]?.focus();
        return;
      }
      const actionBtn = e.target.closest("[data-action]");
      if (actionBtn && this.options.onAction) { this.options.onAction(actionBtn.dataset.action); return; }
      if (e.target.closest("a, button")) return;
      const row = findRow(e.target);
      if (row && this.options.onRowClick) this.options.onRowClick(row);
    });

    this.container.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" && e.key !== " ") return;
      if (!e.target.matches("tr[data-key]")) return;
      e.preventDefault();
      const row = findRow(e.target);
      if (row && this.options.onRowClick) this.options.onRowClick(row);
    });
  }
};
