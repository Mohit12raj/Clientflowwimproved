/* ==========================================================
   Component: SummaryCard (one cell of the dashboard stat strip)
   EW.ui.SummaryCard({ label, value, icon, tone, change, compareLabel, note, series, invertChange })
   EW.ui.SummaryCard.skeleton()
   ========================================================== */
window.EW = window.EW || {};
EW.ui = EW.ui || {};

EW.ui.SummaryCard = (() => {
  const { escapeHTML } = EW.utils;

  /** Tiny trend line from an array of numbers */
  function sparkline(values = []) {
    if (values.length < 2) return "";
    const w = 120, h = 32, max = Math.max(...values, 1);
    const step = w / (values.length - 1);
    const points = values.map((v, i) => `${(i * step).toFixed(1)},${(h - 2 - (v / max) * (h - 6)).toFixed(1)}`);
    return `
      <svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">
        <polyline points="0,${h} ${points.join(" ")} ${w},${h}" class="spark-fill"/>
        <polyline points="${points.join(" ")}" class="spark-line"/>
      </svg>`;
  }

  function changeChip(change, compareLabel, invert) {
    if (change === null) return `<span class="chip chip-new">New vs ${escapeHTML(compareLabel)}</span>`;
    if (change === 0) return `<span class="chip chip-flat">No change vs ${escapeHTML(compareLabel)}</span>`;
    const up = change > 0;
    const good = invert ? !up : up;
    return `<span class="chip ${good ? "chip-good" : "chip-bad"}">${up ? "▲" : "▼"} ${Math.abs(change)}% vs ${escapeHTML(compareLabel)}</span>`;
  }

  function SummaryCard({ label, value, icon, tone = "teal", change, compareLabel, note, series, invertChange = false }) {
    return `
      <article class="summary-card tone-${tone}">
        <header>
          <span class="summary-icon">${EW.icons[icon] || ""}</span>
          <h3>${escapeHTML(label)}</h3>
        </header>
        <div class="summary-value num">${value}</div>
        <p class="summary-note">${note || ""}</p>
        <footer>
          ${compareLabel ? changeChip(change, compareLabel, invertChange) : ""}
          ${sparkline(series)}
        </footer>
      </article>`;
  }

  SummaryCard.skeleton = () => `
    <article class="summary-card is-loading" aria-hidden="true">
      <header><span class="skeleton skeleton-icon"></span><span class="skeleton skeleton-text" style="width:55%"></span></header>
      <div class="skeleton skeleton-value"></div>
      <span class="skeleton skeleton-text" style="width:70%"></span>
      <footer><span class="skeleton skeleton-text" style="width:45%"></span></footer>
    </article>`;

  return SummaryCard;
})();
