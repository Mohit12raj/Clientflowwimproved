/* ==========================================================
   Component: Button
   EW.ui.Button({ label, variant, icon, type, size, href, attrs })
   variant: "primary" | "secondary" | "ghost" | "danger"
   ========================================================== */
window.EW = window.EW || {};
EW.ui = EW.ui || {};

EW.ui.Button = (() => {
  const { cx, attrs, escapeHTML } = EW.utils;

  function Button({ label = "", variant = "primary", icon, iconOnly = false, type = "button", size, href, className, attrs: extra = {} } = {}) {
    const classes = cx("btn", `btn-${variant}`, size && `btn-${size}`, iconOnly && "btn-icon", className);
    const inner = (icon ? EW.icons[icon] : "") + (iconOnly ? `<span class="sr-only">${escapeHTML(label)}</span>` : `<span>${escapeHTML(label)}</span>`);
    if (href) return `<a class="${classes}" href="${escapeHTML(href)}"${attrs(extra)}>${inner}</a>`;
    return `<button type="${type}" class="${classes}"${attrs(extra)}>${inner}</button>`;
  }

  /** Show a spinner and disable the button while an action runs */
  Button.setLoading = (button, loading, loadingLabel = "Working…") => {
    if (!button) return;
    if (loading) {
      button.dataset.idleHtml = button.innerHTML;
      button.disabled = true;
      button.setAttribute("aria-busy", "true");
      button.innerHTML = `<span class="spinner" aria-hidden="true"></span><span>${escapeHTML(loadingLabel)}</span>`;
    } else {
      button.disabled = false;
      button.removeAttribute("aria-busy");
      if (button.dataset.idleHtml) button.innerHTML = button.dataset.idleHtml;
    }
  };

  return Button;
})();
