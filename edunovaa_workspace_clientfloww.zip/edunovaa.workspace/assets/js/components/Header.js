/* ==========================================================
   Component: Header (top bar)
   EW.ui.Header({ user, alerts }) -> HTML for <header id="topbar">
   ========================================================== */
window.EW = window.EW || {};
EW.ui = EW.ui || {};

EW.ui.Header = (() => {
  const { escapeHTML, initials, avatarColor } = EW.utils;

  function Header({ user, alerts = [] }) {
    return `
      ${EW.ui.Button({ label: "Toggle menu", icon: "panel", iconOnly: true, variant: "ghost", className: "menu-toggle", attrs: { "data-menu-toggle": "", "aria-controls": "sidebar", "aria-expanded": "false" } })}

      <form class="header-search" role="search" data-global-search>
        ${EW.ui.SearchInput({ id: "globalSearchInput", label: "Search customers", placeholder: "Search customers by name, company or phone" })}
      </form>

      <div class="header-actions">
        <div class="popover-wrap">
          <button type="button" class="btn btn-ghost btn-icon" data-popover="alerts" aria-haspopup="true" aria-expanded="false" title="Needs attention">
            ${EW.icons.bell}<span class="sr-only">Needs attention, ${alerts.length} items</span>
            ${alerts.length ? `<span class="bubble">${alerts.length}</span>` : ""}
          </button>
          <div class="popover" id="popover-alerts" role="menu">
            <p class="popover-title">High priority, still pending</p>
            ${alerts.length ? alerts.map(a => `
              <a role="menuitem" href="customers.html?id=${encodeURIComponent(a.customerId)}" class="popover-item">
                <strong>${escapeHTML(a.title)}</strong>
                <span>${escapeHTML(a.id)}, raised ${escapeHTML(EW.format.relativeDate(a.requestedOn).toLowerCase())}</span>
              </a>`).join("") : `<p class="popover-empty">Nothing urgent right now.</p>`}
          </div>
        </div>

        <div class="popover-wrap">
          <button type="button" class="user-chip" data-popover="user" aria-haspopup="true" aria-expanded="false">
            <span class="avatar avatar-sm" style="background:${avatarColor(user.name)}">${initials(user.name)}</span>
            <span class="user-chip-name">${escapeHTML(user.name)}</span>
            ${EW.icons.chevronDown}
          </button>
          <div class="popover popover-user" id="popover-user" role="menu">
            <div class="popover-profile"><strong>${escapeHTML(user.name)}</strong><span>${escapeHTML(user.email)}</span></div>
            <button type="button" role="menuitem" class="popover-item is-danger" data-logout>${EW.icons.logout}<span>Sign out</span></button>
          </div>
        </div>
      </div>`;
  }

  return Header;
})();
