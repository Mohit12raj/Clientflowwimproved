/* ==========================================================
   Component: Sidebar
   EW.ui.Sidebar({ active, user }) -> HTML for <aside id="sidebar">
   Collapses to an icon rail on tablet, slides in on mobile.
   ========================================================== */
window.EW = window.EW || {};
EW.ui = EW.ui || {};

EW.ui.Sidebar = (() => {
  const { escapeHTML, initials, avatarColor } = EW.utils;

  const NAV = [
    { id: "dashboard", label: "Dashboard", icon: "dashboard", href: "dashboard.html" },
    { id: "customers", label: "Customers", icon: "users",     href: "customers.html", count: () => EW.store.getCustomers().length }
  ];
  const LATER = [
    { label: "Service requests", icon: "inbox" },
    { label: "Invoices",         icon: "receipt" },
    { label: "Reports",          icon: "chart" }
  ];

  function Sidebar({ active, user }) {
    return `
      <div class="sidebar-brand">
        <span class="brand-mark" aria-hidden="true">e</span>
        <span class="brand-text"><strong>Edunovaa</strong><span>Workspace</span></span>
      </div>

      <nav class="sidebar-nav" aria-label="Main">
        ${NAV.map(item => `
          <a href="${item.href}" class="nav-link${item.id === active ? " is-active" : ""}" ${item.id === active ? 'aria-current="page"' : ""} data-tooltip="${escapeHTML(item.label)}">
            ${EW.icons[item.icon]}
            <span class="nav-label">${escapeHTML(item.label)}</span>
            ${item.count ? `<span class="nav-count">${item.count()}</span>` : ""}
          </a>`).join("")}

        <p class="nav-heading">Planned</p>
        ${LATER.map(item => `
          <span class="nav-link is-disabled" aria-disabled="true" data-tooltip="${escapeHTML(item.label)} (planned)">
            ${EW.icons[item.icon]}<span class="nav-label">${escapeHTML(item.label)}</span>
          </span>`).join("")}
      </nav>

      <div class="sidebar-user">
        <span class="avatar avatar-sm" style="background:${avatarColor(user.name)}">${initials(user.name)}</span>
        <span class="who"><strong>${escapeHTML(user.name)}</strong><span>${escapeHTML(user.role)}</span></span>
        ${EW.ui.Button({ label: "Sign out", icon: "logout", iconOnly: true, variant: "ghost", className: "sidebar-logout", attrs: { "data-logout": "", title: "Sign out" } })}
      </div>`;
  }

  return Sidebar;
})();
