/* ==========================================================
   Component: EmptyState
   EW.ui.EmptyState({ icon, title, message, actions:[{label, action, variant, icon}] })
   Buttons carry data-action so the parent can react.
   ========================================================== */
window.EW = window.EW || {};
EW.ui = EW.ui || {};

EW.ui.EmptyState = function EmptyState({ icon = "search", title, message, actions = [], compact = false } = {}) {
  const { escapeHTML } = EW.utils;
  return `
    <div class="empty-state${compact ? " is-compact" : ""}" role="status">
      <div class="empty-icon">${EW.icons[icon] || ""}</div>
      <h3>${escapeHTML(title)}</h3>
      ${message ? `<p>${escapeHTML(message)}</p>` : ""}
      ${actions.length ? `<div class="empty-actions">${actions.map(a =>
        EW.ui.Button({ label: a.label, variant: a.variant || "secondary", icon: a.icon, attrs: { "data-action": a.action } })
      ).join("")}</div>` : ""}
    </div>`;
};
